﻿using System;
using System.Linq;

namespace BookstoreUpdated.Models
{
    public interface IBookstoreRepository
    {
        IQueryable<Book> Books { get; }
    }
}
