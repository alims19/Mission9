﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace BookstoreUpdated.Models
{
    public class EFCheckoutRepository : ICheckoutRepository
    {
        private BookstoreContext context;

        //Constructor
        public EFCheckoutRepository(BookstoreContext temp)
        {
            context = temp;
        }

        public IQueryable<Checkout> Checkout => context.Checkout.Include(x => x.Lines).ThenInclude(x => x.Book);

        public void SaveCart(Checkout c)
        {
            context.AttachRange(c.Lines.Select(x => x.Book));

            if (c.CheckoutId == 0)
            {
                context.Checkout.Add(c);
            }

            context.SaveChanges();
        }
    }
}