﻿using System;
using System.Linq;

namespace BookstoreUpdated.Models
{
    public interface ICheckoutRepository
    {
        IQueryable<Checkout> Checkout { get; }

        public void SaveCart(Checkout c);
    }
}
